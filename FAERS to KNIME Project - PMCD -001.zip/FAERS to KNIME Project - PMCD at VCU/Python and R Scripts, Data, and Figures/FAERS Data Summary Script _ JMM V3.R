  # Set the working environment and library setup----
  library(tidyr)
  library(ggplot2)
  library(dplyr)
  library(plyr)
  library(stringr)
  library(data.table)
  setwd('J:/VCU PMCD/FAERS Processing 2021') # This will change depending on system; there is a better way to do this, but will suffice for now - JMM 12102021
  df <- read.csv('raw_data.csv')
  
  # For now, drop the reporter_occupation.
  # df <- df %>% select(-reporter_occupation) #This will need to be added back in a further analysis # JMM 12162021
  # Drop artifact columns - get suad to fix this in her Python code later - JMM 12172021
  
  # If indication is not present for that active substance, that means that that was not a cancer indication.
  
  # We will need to determine if the missingness of gender/weight/age can be explained by any of the other covariates
  # For the sake of this preliminary analysis, we will assume MCAR, and impute as Unknown
  # Clean variables gender, active_substance, and indi_pt
  df$gender <- as.factor(df$gender)
  df$Active_Substance <- as.character(df$Active_Substance)
  df$indi_pt <- as.character(df$indi_pt)
  
  df <-
    df %>% mutate(
      gender = ifelse(gender == 'M', 0, ifelse(
        gender == 'F', 1, ifelse(gender == 'I' |
                                gender == 'P' | gender == 'UNK', 2, NA)
      )),
      Active_Substance = ifelse(Active_Substance == '', NA, Active_Substance),
      indi_pt = ifelse(indi_pt == '', NA, indi_pt),
      occr_country = ifelse(occr_country == '', NA, occr_country)
    )
  
  # Determine the levels / number of different countries (will need to operationalize later)...
  # levels(as.factor(df$occr_country))
  # [1] "AD" "AE" "AF" "AL" "AM" "AO" "AR" "AT" "AU" "AZ" "BA" "BD" "BE" "BF" "BG" "BH" "BO" "BR" "BS" "BY" "CA" "CH" "CL"
  # [24] "CM" "CN" "CO" "CR" "CU" "CY" "CZ" "DE" "DK" "DO" "DZ" "EC" "EE" "EG" "ES" "ET" "FI" "FJ" "FR" "GB" "GE" "GH" "GR"
  # [47] "GT" "GU" "HK" "HN" "HR" "HU" "ID" "IE" "IL" "IN" "IQ" "IR" "IS" "IT" "JM" "JO" "JP" "KE" "KG" "KP" "KR" "KW" "KZ"
  # [70] "LB" "LC" "LK" "LS" "LT" "LU" "LV" "LY" "MA" "MD" "ME" "MM" "MO" "MX" "MY" "NG" "NL" "NO" "NP" "NZ" "OM" "PA" "PE"
  # [93] "PH" "PK" "PL" "PR" "PS" "PT" "PY" "QA" "RO" "RS" "RU" "SA" "SD" "SE" "SG" "SI" "SK" "SV" "SZ" "TH" "TJ" "TM" "TN"
  # [116] "TR" "TT" "TW" "TZ" "UA" "UM" "US" "UY" "UZ" "VE" "VI" "VN" "VU" "ZA"
  
  df$gender[is.na(df$gender)] <- 2 # Assuming that Unknown is MCAR
  
  # Clean all missing values by filling in missingness (as an artifact 
  # of our python script, not actual missingess) based on that patient's
  # previously reported caseid, caseversion, event_dt, age, sex, and wt
  df_clean <- df %>% group_by(primaryid) %>%
    # fill(caseid, caseversion, event_dt, age, gender, wt) %>% ungroup()
    fill(event_dt, age, gender, wt) %>% ungroup()  # removed caseid and caseversion for new version of data set - JM 122022021
  
  # df_clean <- df_clean %>% select(-caseid, -caseversion) # CASE ID provides no necessary information not captured in primaryid - JMM 12102021
  # removed caseid and caseversion for new version of data set - JM 122022021
  
  df_clean <- df_clean %>% group_by(primaryid) %>% drop_na(reporter_occupation, age, event_dt, wt, indi_pt, Active_Substance, occr_country) # Drop all patients that have NA for age, event_dt, active substance, indication, and wt
  
  # Create a world region column
  # We are only interested in US/Canada, European, Asian, or "Other" countries
  df_clean <- mutate(df_clean,
      world_region = ifelse(
        occr_country == 'AT' |
          occr_country == 'BE' |
          occr_country == 'BG' |
          occr_country == 'HR' |
          occr_country == 'CY' |
          occr_country == 'CZ' |
          occr_country == 'DK' |
          occr_country == 'EE' |
          occr_country == 'FI' |
          occr_country == 'FR' |
          occr_country == 'DE' |
          occr_country == 'GR' |
          occr_country == 'HU' |
          occr_country == 'IE' |
          occr_country == 'IT' |
          occr_country == 'LV' |
          occr_country == 'LV' |
          occr_country == 'LT' |
          occr_country == 'LU' |
          occr_country == 'MT' |
          occr_country == 'NL' |
          occr_country == 'PL' |
          occr_country == 'PT' |
          occr_country == 'RO' |
          occr_country == 'SK' |
          occr_country == 'SI' |
          occr_country == 'ES' |
          occr_country == 'SE' |
          occr_country == 'GB',
        'EUROPE',
        ifelse(
          occr_country == 'AF' |
            occr_country == 'BG' |
            occr_country == 'BX' |
            occr_country == 'CB' |
            occr_country == 'CH' |
            occr_country == 'GZ' |
            occr_country == 'II' |
            occr_country == 'IR' |
            occr_country == 'IY' |
            occr_country == 'JA' |
            occr_country == 'KN' |
            occr_country == 'KU' |
            occr_country == 'LE' |
            occr_country == 'MY' |
            occr_country == 'NP' |
            occr_country == 'PK' |
            occr_country == 'PF' |
            occr_country == 'QA' |
            occr_country == 'SI' |
            occr_country == 'CE' |
            occr_country == 'TH' |
            occr_country == 'TS' |
            occr_country == 'WJ' |
            occr_country == 'YS' |
            occr_country == 'BA' |
            occr_country == 'BT' |
            occr_country == 'BR' |
            occr_country == 'CC' |
            occr_country == 'CY' |
            occr_country == 'HK' |
            occr_country == 'IO' |
            occr_country == 'IQ' |
            occr_country == 'IS' |
            occr_country == 'JO' |
            occr_country == 'KO' |
            occr_country == 'LS' |
            occr_country == 'MH' |
            occr_country == 'MP' |
            occr_country == 'MK' |
            occr_country == 'PP' |
            occr_country == 'PH' |
            occr_country == 'SU' |
            occr_country == 'XP' |
            occr_country == 'SY' |
            occr_country == 'TU' |
            occr_country == 'VM' |
            occr_country == 'YE',
          'ASIA',
          ifelse(
            occr_country == 'US' |
              occr_country == 'CA',
            'USA/CANADA',
            'OTHER'
          )
        )
      )
    )
  
  # Total patients without dropping NA? Total = 
  # Total (-event_dt) = 
  # Total (-age) = 
  # Total (-wt) = 
  # Total (-age, event_dt) = 
  # Total (-wt, age) = 
  # Total (-wt, event_dt) = 
  
  # Droping all missing values for indications and active substance does NOT affect the number of distinct patients
  
  # TRANSFORM THE LONG MATRIX INTO THE FINAL DATA FORMAT----
  patient_num <- df_clean %>% distinct(primaryid) # This is the subset of the total population from FAERS
  nrow(patient_num) # Total = 11655 (BEV group all inclusive)
  # With including the ASA group = 73421
  # Dropping missing countries resulted in Total = 11329
  
  df_clean <- df_clean %>% ungroup() # IF not ungrouped, this will break the filtering function below
  # Assign a region depending on the country of occurring reaction
  
  
  # For indication - gynecologic cancer indication
  gyn_terms <- c("ovarian cancer",
                 "ovarian epithelial cancer",
                 "endometrial cancer",
                 "fallopian tube cancer",
                 "ovarian cancer stage iii",
                 "uterine cancer",
                 "cervix cancer metastatic",
                 "cervix carcinoma",
                 "cervix carcinoma recurrent",
                 "ovarian cancer metastatic",
                 "ovarian cancer recurrent",
                 "ovarian clear cell carcinoma",
                 "ovarian epithelial cancer recurrent",
                 "ovarian neoplasm",
                 "adenocarcinoma of the cervix",
                 "cervix carcinoma stage i",
                 "cervix carcinoma stage ii",
                 "cervix carcinoma stage iv",
                 "endometrial adenocarcinoma",
                 "endometrial cancer metastatic",
                 "endometrial cancer recurrent",
                 "fallopian tube cancer metastatic",
                 "genital neoplasm malignant female",
                 "ovarian cancer stage ii",
                 "ovarian cancer stage iv",
                 "ovarian epithelial cancer metastatic",
                 "vaginal cancer",
                 "vulval cancer",
                 "endometrial cancer stage iv",
                 "ovarian endometrioid carcinoma",
                 "ureteric cancer",
                 "adenosquamous carcinoma of the cervix",
                 "adenosquamous cell carcinoma",
                 "adnexa uteri mass",
                 "cervix neoplasm",
                 "fallopian tube cancer stage iv",
                 "fallopian tube neoplasm",
                 "female reproductive tract carcinoma in situ",
                 "genital disorder female",
                 "germ cell neoplasm",
                 "gestational trophoblastic tumor",
                 "metastatic uterine cancer",
                 "ovarian epithelial cancer stage iii",
                 "ovarian germ cell tumor",
                 "ovarian germ cell tumor mixed",
                 "ovarian granulosa cell tumor",
                 "squamous cell carcinoma of the cervix",
                 "vaginal adenocarcinoma",
                 "vaginal cancer metastatic")
  
  # For indication - other cancer terms
  
  cancer_terms <- c("breast cancer",
       "colorectal cancer metastatic",
       "colorectal cancer",
       "non-small cell lung cancer metastatic",
       "non-small cell lung cancer",
       "breast cancer metastatic",
       "colon cancer",
       "cancer pain",
       "rectal cancer",
       "breast cancer female",
       "colon cancer metastatic",
       "non-small cell lung cancer stage iv",
       "rectal cancer metastatic",
       "rectal cancer stage iv",
       "gastrointestinal cancer metastatic",
       "hepatic cancer",
       "appendix cancer",
       "brain cancer metastatic",
       "lung cancer metastatic",
       "breast cancer stage iv",
       "gastric cancer",
       "rectal cancer recurrent",
       "colon cancer stage iv",
       "rectosigmoid cancer",
       "cancer surgery",
       "breast cancer recurrent",
       "breast cancer stage i",
       "prostate cancer",
       "renal cancer",
       "small cell lung cancer",
       "renal cancer metastatic",
       "prostate cancer metastatic",
       "endometrial cancer recurrent",
       "colorectal cancer stage iv",
       "colon cancer recurrent",
       "her2 negative breast cancer",
       "breast cancer stage ii",
       "colon cancer stage iii",
       "retroperitoneal cancer",
       "hepatic cancer metastatic",
       "nasopharyngeal cancer",
       "endometrial cancer stage iv",
       "large cell lung cancer",
       "anal cancer",
       "thyroid cancer",
       "oesophageal cancer metastatic",
       "rectosigmoid cancer metastatic",
       "her-2 positive breast cancer",
       "gastrooesophageal cancer",
       "triple negative breast cancer",
       "colon cancer stage 0",
       "colorectal cancer recurrent",
       "bone cancer metastatic",
       "bone cancer",
       "non-small cell lung cancer recurrent",
       "renal cancer stage iv",
       "metastatic gastric cancer",
       "rectosigmoid cancer stage iii",
       "pharyngeal cancer",
       "lip and/or oral cavity cancer",
       "rectosigmoid cancer recurrent",
       "colon cancer stage ii",
       "head and neck cancer metastatic",
       "bladder cancer",
       "adrenal gland cancer",
       "large cell lung cancer metastatic",
       "hypopharyngeal cancer")
  
  # For reaction - hypertension reaction terms
  # rxn_terms <- c("hypertension",
  #                "essential hypertension",
  #                "diastolic hypertension",
  #                "withdrawal hypertension",
  #                "secondary hypertension",
  #                "malignant hypertension",
  #                "systolic hypertension",
  #                "renovascular hypertension",
  #                "accelerated hypertension",
  #                "labile hypertension")
  HTN_rxns <- c("hypertension",
                "essential hypertension",
                "diastolic hypertension",
                "withdrawal hypertension",
                "secondary hypertension",
                "malignant hypertension",
                "systolic hypertension",
                "renovascular hypertension",
                "accelerated hypertension",
                "labile hypertension"
  )
  
  # For active substance - hypertension medications
  HTN_meds <- c("hydrochlorothiazide", 
                "chlorthalidone", 
                "amlodipine", 
                "nifedipine", 
                "diltiazem", 
                "verapamil", 
                "lisinopril",
                "enalapril", 
                "captopril", 
                "ramipril", 
                "benazepril", 
                "losartan", 
                "olmesartan", 
                "candesartan", 
                "telmisartan",
                "valsartan", # added this to keep the list complete - JMM 12172021
                "metoprolol", 
                "carvedilol", 
                "nebivolol", 
                "bisoprolol", 
                "hydralazine", 
                "clonidine", 
                "furosemide", 
                "torsemide",
                "bumetanide", 
                "spironolactone")
  
  # Create the concurrent HTN med column, and the indication class column
  df_clean$total_HTN_med <-
    sapply(gregexpr(paste0(HTN_meds, collapse = "|"), df_clean$Active_Substance), function(x) # apply this substring matching pattern function to the column "Active substance"
      ifelse(-1 %in% x, 0, length(x))) # if active substance is hypertension med, count as 1 (Yes), else count as 0 (No)
  
  # Create the cooccurring HTN_rxn column
  df_clean$HTN_rxn <-
    sapply(gregexpr(paste0(HTN_rxns, collapse = "|"), df_clean$Reaction), function(x) # apply this substring matching pattern function to the column "Reaction"
      ifelse(-1 %in% x, 0, length(x))) # if reaction is hypertension rxn, count as 1 (Yes), else count as 0 (No)
  
  # Create the cooccurring gyn_cancer_rxn column
  df_clean$gyn_cancer_rxn <-
    sapply(gregexpr(paste0(gyn_terms, collapse = "|"), df_clean$Reaction), function(x) # apply this substring matching pattern function to the column "Reaction"
      ifelse(-1 %in% x, 0, length(x))) # if reaction is hypertension rxn, count as 1 (Yes), else count as 0 (No)
  
  # There is a better way to do the following (operationalizing it, putting it in a function...), but for now... - JMM 12172021
  # First, determine if indi_pt is within the gyn_terms
  df_clean$indication_class1 <- 
    sapply(gregexpr(paste0(gyn_terms, collapse = "|"), df_clean$indi_pt), function(x) # apply this substring matching pattern function to the column "indi_pt"
      ifelse(-1 %in% x, NA, 0)) # if indi_pt is gyn_cancer, count as 0 (Yes), else count as NA (No)
  
  # write.csv(unique(df_clean$indi_pt), "All_indication_terms.csv")
  
  # Second, determine if indi_pt is related to cancer (outside of gyn_terms)
  df_clean$indication_class2 <- 
    sapply(gregexpr(paste0(cancer_terms, collapse = "|"), df_clean$indi_pt), function(x) # apply this substring matching pattern function to the column "indi_pt"
      ifelse(-1 %in% x, NA, 1)) # if indi_pt is cancer, count as 1 (Yes), else count as NA (No)
  
  # Thirdly, determine if indi_pt is not in either cancer term
  total_cancer_terms <- c(gyn_terms, cancer_terms)
  
  df_clean$indication_class3 <- 
    sapply(gregexpr(paste0(total_cancer_terms, collapse = "|"), df_clean$indi_pt), function(x) # apply this substring matching pattern function to the column "indi_pt"
      ifelse(-1 %in% x, 2, NA)) # if indi_pt is not in total_cancer_terms, count as 2 (Yes), else count as NA (No)
  
  # Lastly, merge the columns on NA
  df_clean <-
    df_clean %>% mutate(indication_class = coalesce(indication_class1, indication_class2, indication_class3)) %>% select(-indication_class1,-indication_class2,-indication_class3)
  
  # Convert the total HT meds into concurrent HT meds
  df_clean$concurrent_HTN_med <- ifelse(df_clean$total_HTN_med > 0, 1, 0) 

  # Convert the total HTN rxns into HT-co-event
  
  
# TRANSFORMATION FUNCTION----
# FAERS_to_wide.fn <- function(x){
  # # Get the 3 variables we want to analyze
  # vars_list<-c('Active_Substance', 'Reaction', 'indi_pt')
  # 
  # for(i in seq_along(vars_list)){
  #   # print(vars_list[i]) # prints the indexed var in the character vector
  # }
  
  x <- df_clean %>% ungroup()
  
  # Operationalize below later - JMM 12172021
  x_AS<-as.data.table(x)[, toString(sort(unique(Active_Substance))), by = list(primaryid, Group, event_dt, reporter_occupation, gender, world_region, occr_country, age, wt,  HTN_rxn, gyn_cancer_rxn, total_HTN_med)]
  x_AS <- as.data.frame(x_AS)
  colnames(x_AS)[13]<-"Active_Substance" # Need to operationalize so when new column is added, does not break the script
  # previously set to 8, was causing errors - JM 122022021
  
  x_RXN<-as.data.table(x)[, toString(sort(unique(Reaction))), by = list(primaryid, Group, event_dt, reporter_occupation, gender, world_region, occr_country, age, wt,  HTN_rxn, gyn_cancer_rxn, total_HTN_med)]
  colnames(x_RXN)[13]<-"Reaction"
  
  x_indi_pt<-as.data.table(x)[, toString(sort(unique(indi_pt))), by = list(primaryid, Group, event_dt, reporter_occupation, gender, world_region, occr_country, age, wt,  HTN_rxn, gyn_cancer_rxn, total_HTN_med)]
  colnames(x_indi_pt)[13]<-"Indication"
  
  x_indi_class<-as.data.table(x)[, toString(sort(unique(as.factor(indication_class)))), by = list(primaryid, Group, event_dt, reporter_occupation, gender, world_region, occr_country, age, wt,  HTN_rxn, gyn_cancer_rxn, total_HTN_med)]
  colnames(x_indi_class)[13]<-"Primary_Indication"
  
  # when converting to string and combining, may have multi-classes for each patient
  # i.e. levels(as.factor(x_indi_class$`Indication Class`))
  # [1] "0"       "0, 1"    "0, 1, 2" "0, 2"    "1"       "1, 2"    "2"    
  # Next, select the first character in the string as the Primary Class
  x_indi_class$Primary_Indication <- as.character(x_indi_class$Primary_Indication)
  x_indi_class$Primary_Indication <- sapply(strsplit(x_indi_class$Primary_Indication, ","), "[", 1)
  # levels(as.factor(x_indi_class$Primary_Indication)) # Check to see if str_split worked as expected
  
  # x_indi_class<-as.data.table(df_clean)[, toString(sort(unique(indication_class))), by = list(primaryid, Group, event_dt, gender, occr_country, age, wt, total_HTN_med)]
  # colnames(x_indi_class)[8]<-"Indication_class"
  
  # do the same with concurrent_HTN_med as what was done with indication_class
  x_concurrent_med<-as.data.table(x)[, toString(sort(unique(as.factor(concurrent_HTN_med)))), by = list(primaryid, Group, event_dt, reporter_occupation, gender, world_region, occr_country, age, wt,  HTN_rxn, gyn_cancer_rxn, total_HTN_med)]
  colnames(x_concurrent_med)[13]<-"concurrent_HTN_med"
  
  # when converting to string and combining, may have multi-classes for each patient
  # i.e. levels(as.factor(x_indi_class$`Indication Class`))
  # [1] "0"       "0, 1"    "0, 1, 2" "0, 2"    "1"       "1, 2"    "2"    
  # Next, select the first character in the string as the Primary Class
  x_concurrent_med$concurrent_HTN_med <- as.character(x_concurrent_med$concurrent_HTN_med)
  x_concurrent_med$concurrent_HTN_med <- sapply(strsplit(x_concurrent_med$concurrent_HTN_med, ","), "[[", 1)
  # levels(as.factor(x_concurrent_med$concurrent_HTN_med))
  
  # final_data <- Reduce(merge, list(x_AS, x_RXN, x_indi_pt, x_indi_class))
  final_data <- Reduce(merge, list(x_AS, x_RXN, x_indi_pt, x_indi_class, x_concurrent_med))
  
  # Reorganize columns
  final_data <-
    final_data %>% select(
      primaryid,
      Group,
      event_dt,
      reporter_occupation,
      gender,
      occr_country,
      world_region,
      age,
      wt,
      concurrent_HTN_med,
      Primary_Indication,
      Active_Substance,
      HTN_rxn,
      gyn_cancer_rxn,
      total_HTN_med,
      Reaction,
      Indication
    )
  
  # There will be duplicates as a result of MULTIPLE GROUPS (i.e. groups 2,3)
  # as well as differences in active substance and concurrent HTN med
  # To correct for these duplicates, will need to aggregate the data - 01062021 JMM
  # Aggregate on primaryid
  final_data <- aggregate(.~primaryid, final_data, paste, collapse=",")
  # final_data2 <- final_data
  
  # split the strings for group, role code, gender, occurring country, age, weight, event date, concurrent medications, and world region
  
  # Next, there are some individuals in group 2 (Bev+ASA) and group 3 (ASA only).
  # Select either groups 1 or 2, if vectorized as multi-groups.
  final_data$Group <- sapply(strsplit(final_data$Group, ","), "[[", 1) 
  # for group, 1 is BEV only, 2 is BEV+ASA, 3 is ASA only
  # levels(as.factor(final_data$Group)) # before splitting
  # [1] "1"       "1,1"     "1,1,1"   "2"       "2,2"     "2,2,2"   "2,2,2,3" "2,2,3"   "2,3"     "3"    
  final_data$gender <- sapply(strsplit(final_data$gender, ","), "[[", 1)
  # final_data$reporter_occupation <- sapply(strsplit(final_data$reporter_occupation, ","), "[[", 1) # Subscript out of bounds - cleaned this column within microsoft excel - JMM 1082022
  final_data$occr_country <- sapply(strsplit(final_data$occr_country, ","), "[[", 1)
  final_data$age <- sapply(strsplit(final_data$age, ","), "[[", 1)
  final_data$wt <- sapply(strsplit(final_data$wt, ","), "[[", 1)
  final_data$event_dt <- sapply(strsplit(final_data$event_dt, ","), "[[", 1)
  final_data$world_region <- sapply(strsplit(final_data$world_region, ","), "[[", 1)
  
  final_data$concurrent_HTN_med <-
    sapply(strsplit(as.character(final_data$concurrent_HTN_med), ","), function(x)
      max(as.numeric(x))) # IF not grabbing the max for concurrent_HTN_med, will result in 0 for all
  
  # get the maximum number for the total number of meds
  final_data$total_HTN_med <-
    sapply(strsplit(as.character(final_data$total_HTN_med), ","), function(x)
      max(as.numeric(x)))
  
  # get the minimum number for the primary indication
  final_data$Primary_Indication <-
    sapply(strsplit(as.character(final_data$Primary_Indication), ","), function(x)
      min(as.numeric(x)))
  
  # get the maximum number for the HTN reactions
  final_data$HTN_rxn <-
    sapply(strsplit(as.character(final_data$HTN_rxn), ","), function(x)
      max(as.numeric(x)))
  
  # get the maximum number for the gyn_cancer_rxns
  final_data$gyn_cancer_rxn <-
    sapply(strsplit(as.character(final_data$gyn_cancer_rxn), ","), function(x)
      max(as.numeric(x)))

  assign("FAERS final data", final_data, envir = .GlobalEnv)
  write.csv(final_data, paste0("FAERS final data ", Sys.Date(),".csv")) # Added world region and hypertension co-occurring reaction columns
# }

# SUMMARY STATISTICS----
  # Before running any of the summary statistics (simple counts), will need to filter for dates that are before the year 2015
  final_data <- read.csv("FAERS final data_.csv")
  
# For total number----
# Get summary statistics on gender, age, reaction number, number by groups, and indication number
df_unq <- nrow(patient_num) # Total = 42498

# For number by group
group_num <- as.data.frame(table(final_data$Group))

group_num$Var1 <- c("Bev","Bev+ASA","ASA")
write.csv(group_num, "FAERS Total BEV and BEV_ASA groups 2015_2020.csv")

df_bev <- filter(final_data, final_data$Group == 1) # Filter for the BEV Group
df_bev_ASA <- filter(final_data, final_data$Group == 2) # Filter for only the BEV + ASA Group
df_ASA <- filter(final_data, final_data$Group == 3) # Filter for the ASA group

# For number by gender
gender_num_bev <- as.data.frame(table(df_bev$gender))
gender_num_bev$Var1 <- c("Male","Female","Unknown")

gender_num_bev_ASA <- as.data.frame(table(df_bev_ASA$gender))
gender_num_bev_ASA$Var1 <- c("Male","Female")

# For reporter occupation
reporter_num_bev <- as.data.frame(table(df_bev$reporter_occupation))

reporter_num_bev_ASA <- as.data.frame(table(df_bev_ASA$reporter_occupation))

# For country of origin
country_or_bev <- as.data.frame(table(df_bev$world_region))

country_or_bev_ASA <- as.data.frame(table(df_bev_ASA$world_region))

# For age
# Convert to numeric first (originally class as character)
df_bev$age <- as.numeric(df_bev$age)
df_bev <- mutate(df_bev,
       age = ifelse(
         age < 18,
         'UNDER 18',
         ifelse(
           age >= 18 & age <= 44 ,
           '18-44',
           ifelse(
             age >= 45 & age <= 64,
             '45-64',
             ifelse(
               age >= 65 & age <= 84,
               '65-84',
               '85+'
             )
           )
         )
       )
)

df_bev_ASA$age <- as.numeric(df_bev_ASA$age)
df_bev_ASA <- mutate(df_bev_ASA,
                 age = ifelse(
                   age < 18,
                   'UNDER 18',
                   ifelse(
                     age >= 18 & age <= 44 ,
                     '18-44',
                     ifelse(
                       age >= 45 & age <= 64,
                       '45-64',
                       ifelse(
                         age >= 65 & age <= 84,
                         '65-84',
                         '85+'
                       )
                     )
                   )
                 )
)

age_bev <- as.data.frame(table(df_bev$age))
age_bev_ASA <- as.data.frame(table(df_bev_ASA$age))

# For indication

indication_bev <- as.data.frame(table(df_bev$Primary_Indication))

indication_bev_ASA <- as.data.frame(table(df_bev_ASA$Primary_Indication))

# Concurrent HTN medication

concurrent_HTN_bev <- as.data.frame(table(df_bev$concurrent_HTN_med))

concurrent_HTN_bev_ASA <- as.data.frame(table(df_bev_ASA$concurrent_HTN_med))

# For weight

avg_wt_bev <- mean(as.numeric(df_bev$wt))
avg_wt_bev_ASA <- mean(as.numeric(df_bev_ASA$wt))

# VISUALIZATION----
# This is a segment of the visualization script (which includes the positve and negative controls scripts)
# Get the first 4 characters of event date, this is the year; then, create a list by years

final_data$event_dt <- substr(final_data$event_dt,1,4)
final_data_list <- split(final_data[-which(names(final_data)=="event_dt")], final_data$event_dt) # splits the dataframe into event dates, use this to operationalize the below barplot function later

# Need to operationalize all of the below...
Barplot_DrugA <-
  data.frame("Event With Drug" = nrow(df_bev_ASA),
             "Event Without Drug" = nrow(df_bev))

Barplot_DrugA <- t(Barplot_DrugA)

colnames(Barplot_DrugA) <- "Total Cases for 2015 - 2020"

Barplot_DrugA <- as.data.frame(Barplot_DrugA)

Barplot_DrugA$Group <- c("Event with Drug", "Event Without Drug")

# Plot 1 will contain the total count data for all severe adverse events
plot1 <-
  ggplot(Barplot_DrugA,
         mapping = aes(Group, `Total Cases for 2015 - 2020`, color = Group)) + geom_bar(stat = "identity", position = "dodge") + labs(
           title = paste0("FAERS Bevacizumab use for all Severe Adverse Events"),
           y = "Total Cases for 2015-2020",
           x = "Aspirin Events"
         ) + geom_text(aes(label =
                             `Total Cases for 2015 - 2020`),
                       position = position_dodge((width = 1)),
                       vjust = -0.5) + scale_y_continuous(limits = c(0, round_any(Barplot_DrugA[2,1], 150, f = ceiling)))

# Plot 2 will contain the total count data for hypertensive events
# For now, only focus on the hypertensive events, not the "hypertensive-related" events

final_data_Pos <- filter(final_data, final_data$HTN_rxn == 1)

df_bev_RxnPos <- filter(final_data_Pos, final_data_Pos$Group == 1)
df_bev_ASA_RxnPos <- filter(final_data_Pos, final_data_Pos$Group == 2)

Barplot_DrugA_RxnsPOS <-
  data.frame("Event With Drug" = nrow(df_bev_ASA_RxnPos),
             "Event Without Drug" = nrow(df_bev_RxnPos))

Barplot_DrugA_RxnsPOS <- t(Barplot_DrugA_RxnsPOS)

colnames(Barplot_DrugA_RxnsPOS) <- "Total Cases for 2015 - 2020"

Barplot_DrugA_RxnsPOS <- as.data.frame(Barplot_DrugA_RxnsPOS)

Barplot_DrugA_RxnsPOS$Group <- c("Event with Drug", "Event Without Drug")

plot2 <-
  ggplot(Barplot_DrugA_RxnsPOS,
         mapping = aes(Group, `Total Cases for 2015 - 2020`, color = Group)) + geom_bar(stat = "identity", position = "dodge") + labs(
           title = paste0("FAERS Bevacizumab use with Hypertension"),
           y = "Total Cases for 2015-2020",
           x = "Aspirin Events"
         ) + geom_text(aes(label =
                             `Total Cases for 2015 - 2020`),
                       position = position_dodge((width = 1)),
                       vjust = -0.5) + scale_y_continuous(limits = c(0, round_any(Barplot_DrugA_RxnsPOS[2,1], 150, f = ceiling)))

print(plot1)
print(plot2)
